import os
import random
import time
import logging
import sqlite3
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("render-discord-bot")

TOKEN = os.getenv("DISCORD_TOKEN")
DATABASE_PATH = os.getenv("DATABASE_PATH", "bot_data.sqlite3")

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing. Add it under Render > Environment.")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
db = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
db.execute("""
CREATE TABLE IF NOT EXISTS warnings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    created_at INTEGER NOT NULL
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER PRIMARY KEY,
    welcome_channel_id INTEGER
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS user_xp (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    xp INTEGER NOT NULL DEFAULT 0,
    level INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
)
""")
db.commit()

def is_guild(interaction: discord.Interaction) -> bool:
    return interaction.guild is not None

def safe_reason(reason: str | None) -> str:
    return (reason or "No reason provided")[:450]

async def member_is_protected(interaction: discord.Interaction, member: discord.Member) -> bool:
    if interaction.guild is None:
        return True
    if member.id == interaction.user.id:
        return True
    if member.id == interaction.guild.owner_id:
        return True
    if isinstance(interaction.user, discord.Member):
        if interaction.user.id != interaction.guild.owner_id and member.top_role >= interaction.user.top_role:
            return True
    me = interaction.guild.me
    if me and member.top_role >= me.top_role:
        return True
    return False

class TicketPanel(discord.ui.View):
    """Persistent ticket panel; custom_id must remain stable between restarts."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Create a ticket",
        style=discord.ButtonStyle.green,
        emoji="🎫",
        custom_id="support:create_ticket:v1",
    )
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("Use this button inside a server.", ephemeral=True)
            return

        existing = discord.utils.get(guild.text_channels, name=f"ticket-{interaction.user.id}")
        if existing:
            await interaction.response.send_message(
                f"You already have an open ticket: {existing.mention}", ephemeral=True
            )
            return

        category = discord.utils.get(guild.categories, name="Tickets")
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, attach_files=True
            ),
        }
        if guild.me:
            overwrites[guild.me] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, manage_channels=True
            )

        try:
            channel = await guild.create_text_channel(
                name=f"ticket-{interaction.user.id}",
                category=category,
                overwrites=overwrites,
                topic=f"Support ticket opened by {interaction.user} ({interaction.user.id})",
                reason="Support ticket created from ticket panel",
            )
            embed = discord.Embed(
                title="Support ticket",
                description=(
                    f"Hello {interaction.user.mention}! Please explain what you need help with.\n"
                    "A moderator will respond when available."
                ),
                color=discord.Color.blurple(),
            )
            await channel.send(embed=embed, view=CloseTicketView())
            await interaction.response.send_message(f"Your ticket is ready: {channel.mention}", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "I need Manage Channels and permission to create/read ticket channels.", ephemeral=True
            )
        except discord.HTTPException:
            await interaction.response.send_message("Couldn't create the ticket. Please try again later.", ephemeral=True)

class CloseTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Close ticket",
        style=discord.ButtonStyle.red,
        emoji="🔒",
        custom_id="support:close_ticket:v1",
    )
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel) or not channel.name.startswith("ticket-"):
            await interaction.response.send_message("This button only works in a ticket channel.", ephemeral=True)
            return
        if not isinstance(interaction.user, discord.Member):
            await interaction.response.send_message("Server membership required.", ephemeral=True)
            return

        has_staff_permission = interaction.user.guild_permissions.manage_channels
        is_ticket_owner = channel.topic and f"({interaction.user.id})" in channel.topic
        if not (has_staff_permission or is_ticket_owner):
            await interaction.response.send_message("Only the ticket owner or staff can close this ticket.", ephemeral=True)
            return

        await interaction.response.send_message("Closing this ticket in 3 seconds…", ephemeral=True)
        await discord.utils.sleep_until(discord.utils.utcnow() + timedelta(seconds=3))
        try:
            await channel.delete(reason=f"Ticket closed by {interaction.user}")
        except discord.Forbidden:
            log.warning("Missing permission to delete ticket channel %s", channel.id)

@bot.event
async def on_ready():
    bot.add_view(TicketPanel())
    bot.add_view(CloseTicketView())
    try:
        synced = await bot.tree.sync()
        log.info("Logged in as %s; synced %s application commands", bot.user, len(synced))
    except Exception:
        log.exception("Slash command sync failed")
    log.info("Bot is ready.")

@bot.event
async def on_member_join(member: discord.Member):
    row = db.execute(
        "SELECT welcome_channel_id FROM settings WHERE guild_id = ?", (member.guild.id,)
    ).fetchone()
    if row and row[0]:
        channel = member.guild.get_channel(row[0])
        if isinstance(channel, discord.TextChannel):
            embed = discord.Embed(
                title="Welcome!",
                description=f"Welcome to **{member.guild.name}**, {member.mention}! 🎉",
                color=discord.Color.green(),
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            try:
                await channel.send(embed=embed)
            except discord.Forbidden:
                log.warning("Can't send welcome message in channel %s", channel.id)

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return

    # Simple activity XP: one small award every 60 seconds, no XP for spammy bursts.
    now = int(time.time())
    key = f"xp_last_{message.guild.id}_{message.author.id}"
    last = getattr(bot, key, 0)
    if now - last >= 60:
        setattr(bot, key, now)
        row = db.execute(
            "SELECT xp, level FROM user_xp WHERE guild_id=? AND user_id=?",
            (message.guild.id, message.author.id),
        ).fetchone()
        xp, level = row if row else (0, 0)
        xp += random.randint(8, 15)
        new_level = int((xp / 100) ** 0.5)
        db.execute(
            """INSERT INTO user_xp (guild_id,user_id,xp,level) VALUES (?,?,?,?)
               ON CONFLICT(guild_id,user_id) DO UPDATE SET xp=excluded.xp, level=excluded.level""",
            (message.guild.id, message.author.id, xp, new_level),
        )
        db.commit()
        if new_level > level:
            try:
                await message.channel.send(f"🎉 {message.author.mention} reached level **{new_level}**!")
            except discord.HTTPException:
                pass

    await bot.process_commands(message)

@bot.tree.command(name="ping", description="Check the bot's response latency")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! `{round(bot.latency * 1000)} ms`")

@bot.tree.command(name="help", description="Show the bot's main features")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Bot commands",
        description="Use slash commands by typing `/` in a server.",
        color=discord.Color.blurple(),
    )
    embed.add_field(name="Utility", value="`/ping` `/serverinfo` `/userinfo` `/avatar` `/poll` `/rank` `/leaderboard`", inline=False)
    embed.add_field(name="Moderation", value="`/clear` `/kick` `/ban` `/timeout` `/untimeout` `/warn` `/warnings` `/lock` `/unlock`", inline=False)
    embed.add_field(name="Setup", value="`/setwelcome` `/ticketpanel`", inline=False)
    embed.set_footer(text="Moderation commands require the relevant server permissions.")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="serverinfo", description="Show information about this server")
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    if not guild:
        await interaction.response.send_message("Use this command in a server.", ephemeral=True)
        return
    embed = discord.Embed(title=guild.name, color=discord.Color.blurple())
    embed.add_field(name="Members", value=str(guild.member_count or "Unknown"))
    embed.add_field(name="Channels", value=str(len(guild.channels)))
    embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="D"), inline=False)
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="userinfo", description="Show information about a member")
@app_commands.describe(member="Member to inspect; defaults to you")
async def userinfo(interaction: discord.Interaction, member: discord.Member | None = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"User info: {member}", color=discord.Color.blurple())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="User ID", value=str(member.id), inline=False)
    embed.add_field(name="Joined server", value=discord.utils.format_dt(member.joined_at, style="D") if member.joined_at else "Unknown", inline=False)
    embed.add_field(name="Account created", value=discord.utils.format_dt(member.created_at, style="D"), inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="avatar", description="Show a member's avatar")
@app_commands.describe(member="Member; defaults to you")
async def avatar(interaction: discord.Interaction, member: discord.Member | None = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"{member.display_name}'s avatar", color=discord.Color.blurple())
    embed.set_image(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="poll", description="Create a yes/no poll")
@app_commands.describe(question="Question to ask the server")
async def poll(interaction: discord.Interaction, question: app_commands.Range[str, 1, 240]):
    embed = discord.Embed(title="📊 Poll", description=question, color=discord.Color.blurple())
    embed.set_footer(text=f"Poll by {interaction.user}")
    await interaction.response.send_message(embed=embed)
    msg = await interaction.original_response()
    await msg.add_reaction("👍")
    await msg.add_reaction("👎")

@bot.tree.command(name="clear", description="Delete 1–100 recent messages")
@app_commands.checks.has_permissions(manage_messages=True)
@app_commands.describe(amount="Number of messages to delete (1–100)")
async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    if not isinstance(interaction.channel, discord.TextChannel):
        await interaction.response.send_message("Use this in a text channel.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    try:
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 Deleted {len(deleted)} messages.", ephemeral=True)
    except discord.Forbidden:
        await interaction.followup.send("I need Manage Messages permission.", ephemeral=True)

@bot.tree.command(name="kick", description="Kick a member")
@app_commands.checks.has_permissions(kick_members=True)
@app_commands.describe(member="Member to kick", reason="Reason")
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if await member_is_protected(interaction, member):
        await interaction.response.send_message("You can't kick yourself, the owner, or a member with an equal/higher role.", ephemeral=True)
        return
    try:
        await member.kick(reason=safe_reason(reason))
        await interaction.response.send_message(f"👢 Kicked **{member}**. Reason: {safe_reason(reason)}")
    except discord.Forbidden:
        await interaction.response.send_message("I lack permission or my role is too low.", ephemeral=True)

@bot.tree.command(name="ban", description="Ban a member")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.describe(member="Member to ban", reason="Reason")
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if await member_is_protected(interaction, member):
        await interaction.response.send_message("You can't ban yourself, the owner, or a member with an equal/higher role.", ephemeral=True)
        return
    try:
        await member.ban(reason=safe_reason(reason), delete_message_seconds=0)
        await interaction.response.send_message(f"🔨 Banned **{member}**. Reason: {safe_reason(reason)}")
    except discord.Forbidden:
        await interaction.response.send_message("I lack permission or my role is too low.", ephemeral=True)

@bot.tree.command(name="timeout", description="Timeout a member for up to 7 days")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.describe(member="Member to timeout", minutes="Duration in minutes (1–10080)", reason="Reason")
async def timeout(interaction: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 10080], reason: str = "No reason provided"):
    if await member_is_protected(interaction, member):
        await interaction.response.send_message("You can't timeout yourself, the owner, or a member with an equal/higher role.", ephemeral=True)
        return
    try:
        await member.timeout(timedelta(minutes=minutes), reason=safe_reason(reason))
        await interaction.response.send_message(f"⏳ Timed out **{member}** for {minutes} minute(s).")
    except discord.Forbidden:
        await interaction.response.send_message("I lack permission or my role is too low.", ephemeral=True)

@bot.tree.command(name="untimeout", description="Remove a member's timeout")
@app_commands.checks.has_permissions(moderate_members=True)
async def untimeout(interaction: discord.Interaction, member: discord.Member):
    if await member_is_protected(interaction, member):
        await interaction.response.send_message("You can't change this member's timeout.", ephemeral=True)
        return
    try:
        await member.timeout(None, reason=f"Timeout removed by {interaction.user}")
        await interaction.response.send_message(f"✅ Removed timeout for **{member}**.")
    except discord.Forbidden:
        await interaction.response.send_message("I lack permission or my role is too low.", ephemeral=True)

@bot.tree.command(name="warn", description="Record a warning for a member")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.describe(member="Member to warn", reason="Reason")
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str):
    if await member_is_protected(interaction, member):
        await interaction.response.send_message("You can't warn yourself, the owner, or a member with an equal/higher role.", ephemeral=True)
        return
    db.execute(
        "INSERT INTO warnings (guild_id,user_id,moderator_id,reason,created_at) VALUES (?,?,?,?,?)",
        (interaction.guild_id, member.id, interaction.user.id, safe_reason(reason), int(time.time())),
    )
    db.commit()
    await interaction.response.send_message(f"⚠️ Warned **{member}**. Reason: {safe_reason(reason)}")

@bot.tree.command(name="warnings", description="List a member's recorded warnings")
@app_commands.checks.has_permissions(moderate_members=True)
async def warnings(interaction: discord.Interaction, member: discord.Member):
    rows = db.execute(
        "SELECT moderator_id, reason, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10",
        (interaction.guild_id, member.id),
    ).fetchall()
    if not rows:
        await interaction.response.send_message(f"No warnings found for {member.mention}.", ephemeral=True)
        return
    lines = [
        f"• <t:{created}:d> — {reason} (moderator <@{moderator}>)"
        for moderator, reason, created in rows
    ]
    embed = discord.Embed(title=f"Warnings for {member}", description="\n".join(lines), color=discord.Color.orange())
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="lock", description="Prevent @everyone from sending messages in this channel")
@app_commands.checks.has_permissions(manage_channels=True)
async def lock(interaction: discord.Interaction):
    channel = interaction.channel
    if not isinstance(channel, discord.TextChannel):
        await interaction.response.send_message("Use this in a text channel.", ephemeral=True)
        return
    overwrite = channel.overwrites_for(interaction.guild.default_role)
    overwrite.send_messages = False
    try:
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite, reason=f"Locked by {interaction.user}")
        await interaction.response.send_message("🔒 Channel locked.")
    except discord.Forbidden:
        await interaction.response.send_message("I need Manage Channels permission.", ephemeral=True)

@bot.tree.command(name="unlock", description="Allow @everyone to send messages in this channel")
@app_commands.checks.has_permissions(manage_channels=True)
async def unlock(interaction: discord.Interaction):
    channel = interaction.channel
    if not isinstance(channel, discord.TextChannel):
        await interaction.response.send_message("Use this in a text channel.", ephemeral=True)
        return
    overwrite = channel.overwrites_for(interaction.guild.default_role)
    overwrite.send_messages = None
    try:
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite, reason=f"Unlocked by {interaction.user}")
        await interaction.response.send_message("🔓 Channel unlocked.")
    except discord.Forbidden:
        await interaction.response.send_message("I need Manage Channels permission.", ephemeral=True)

@bot.tree.command(name="setwelcome", description="Set the channel for join messages")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(channel="Channel where welcome messages should appear")
async def setwelcome(interaction: discord.Interaction, channel: discord.TextChannel):
    db.execute(
        """INSERT INTO settings (guild_id,welcome_channel_id) VALUES (?,?)
           ON CONFLICT(guild_id) DO UPDATE SET welcome_channel_id=excluded.welcome_channel_id""",
        (interaction.guild_id, channel.id),
    )
    db.commit()
    await interaction.response.send_message(f"✅ Welcome messages will be sent to {channel.mention}.", ephemeral=True)

@bot.tree.command(name="ticketpanel", description="Post a support-ticket button panel")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(channel="Channel for the ticket panel")
async def ticketpanel(interaction: discord.Interaction, channel: discord.TextChannel):
    embed = discord.Embed(
        title="Need help?",
        description="Click **Create a ticket** below to open a private support channel.",
        color=discord.Color.blurple(),
    )
    try:
        await channel.send(embed=embed, view=TicketPanel())
        await interaction.response.send_message(f"✅ Ticket panel posted in {channel.mention}.", ephemeral=True)
    except discord.Forbidden:
        await interaction.response.send_message("I can't send messages in that channel.", ephemeral=True)

@bot.tree.command(name="rank", description="Show your activity level")
@app_commands.describe(member="Member; defaults to you")
async def rank(interaction: discord.Interaction, member: discord.Member | None = None):
    member = member or interaction.user
    row = db.execute(
        "SELECT xp, level FROM user_xp WHERE guild_id=? AND user_id=?",
        (interaction.guild_id, member.id),
    ).fetchone()
    xp, level = row if row else (0, 0)
    embed = discord.Embed(title=f"🏅 Rank: {member.display_name}", color=discord.Color.gold())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="Level", value=str(level))
    embed.add_field(name="XP", value=str(xp))
    embed.add_field(name="Next level", value=str((level + 1) ** 2 * 100))
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="leaderboard", description="Show the top 10 members by XP")
async def leaderboard(interaction: discord.Interaction):
    rows = db.execute(
        "SELECT user_id,xp,level FROM user_xp WHERE guild_id=? ORDER BY xp DESC LIMIT 10",
        (interaction.guild_id,),
    ).fetchall()
    if not rows:
        await interaction.response.send_message("No activity recorded yet.")
        return
    lines = [f"**{i}.** <@{uid}> — level {level} ({xp} XP)" for i, (uid, xp, level) in enumerate(rows, start=1)]
    embed = discord.Embed(title="🏆 Server leaderboard", description="\n".join(lines), color=discord.Color.gold())
    await interaction.response.send_message(embed=embed)

@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        message = "You don't have the server permission required for this command."
    elif isinstance(error, app_commands.CommandOnCooldown):
        message = "Please wait before using that command again."
    else:
        original = getattr(error, "original", error)
        log.exception("Slash command failed", exc_info=original)
        message = "Something went wrong. Check the bot permissions and Render logs."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)
    except discord.HTTPException:
        pass

bot.run(TOKEN)
