# Discord Community Bot (Python + Render)

Features:
- Slash commands: `/help`, `/ping`, `/serverinfo`, `/userinfo`, `/avatar`, `/poll`
- Moderation: `/clear`, `/kick`, `/ban`, `/timeout`, `/untimeout`, `/warn`, `/warnings`, `/lock`, `/unlock`
- Welcome messages: `/setwelcome`
- Private support tickets: `/ticketpanel`, create/close buttons
- Activity XP: `/rank`, `/leaderboard`
- SQLite database for warnings, welcome settings, and XP
- Token read from environment variable; never hard-code it

## 1. Create the Discord application
1. Go to https://discord.com/developers/applications and create an application.
2. Open **Bot** and create/reset the bot token. Treat the token like a password.
3. Under **Bot > Privileged Gateway Intents**, enable **Server Members Intent** and **Message Content Intent**.
4. Open **OAuth2 > URL Generator**. Select scopes `bot` and `applications.commands`.
5. Choose only the permissions needed. This bot commonly needs View Channels, Send Messages, Embed Links, Read Message History, Add Reactions, Manage Messages, Kick Members, Ban Members, Moderate Members, Manage Channels, and Manage Roles only if you choose to add role features. Avoid Administrator if possible.
6. Use the generated URL to invite the bot to your server. Make sure the bot's role is above the roles it must moderate.

## 2. Deploy to Render
1. Put `bot.py`, `requirements.txt`, `render.yaml`, `.gitignore`, and `README.md` in a GitHub repository.
2. In Render, choose **New > Blueprint** and connect the repository.
3. Review the service and create it. The Blueprint config creates a **Background Worker** and a persistent disk for SQLite data.
4. In the Render service's **Environment** settings, set `DISCORD_TOKEN` to the bot token. Do not commit it to GitHub or paste it into `bot.py`.
5. Deploy. Check the Render logs for `Bot is ready.`

If you create the worker manually instead of using the Blueprint:
- Runtime: Python
- Build command: `pip install -r requirements.txt`
- Start command: `python bot.py`
- Add environment variable `DISCORD_TOKEN`
- If you want SQLite data to survive deploys, attach a persistent disk and set `DATABASE_PATH` to a file path on that disk. On Render, a persistent disk may require a paid plan.

## 3. Use it
Slash commands can take a short time to appear after first sync. In your server, type `/` to find them.
- Run `/setwelcome` to choose a welcome channel.
- Run `/ticketpanel` to post a support-ticket panel in a channel.
- Moderation commands require your own relevant server permission.
- `/clear` deletes up to 100 recent messages.
- `/timeout` duration is 1–10080 minutes (up to 7 days).

## Important notes
- Never share your bot token. If it leaks, reset it in the Developer Portal immediately and update Render's environment variable.
- Give the bot only the permissions it needs. Discord role hierarchy still applies.
- `Message Content Intent` is needed for XP tracking via `on_message`; `Server Members Intent` is needed for welcome events and member options.
- Render's free service offerings and persistent-disk availability can change. Check current Render plan details before deploying.
- SQLite works for a single worker. Do not run multiple copies of this bot against the same SQLite file.
- This is a starter community bot. Test moderation and ticket behavior in a private test server before using it in a busy server.
